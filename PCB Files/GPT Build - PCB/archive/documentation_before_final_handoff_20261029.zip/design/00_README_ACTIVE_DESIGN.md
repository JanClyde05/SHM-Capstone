# ACTIVE HARDWARE DESIGN FILES — SOURCE OF TRUTH

> **FOR ALL USERS AND AI ASSISTANTS:**
> This directory (`PCB Files/GPT Build - PCB/design/`) contains the **OFFICIAL, ACTIVE, AND CORRECTED** hardware design files for the SHM Capstone project.

---

## 1. Active Design Files (Open & Edit These)

| Artifact | File Path | Status | Verification Evidence |
| :--- | :--- | :---: | :--- |
| **KiCad Project** | [`SHM_Node_R2.kicad_pro`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Node_R2.kicad_pro) | **Active** | Primary project entry point |
| **Schematic** | [`SHM_Node_R2.kicad_sch`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Node_R2.kicad_sch) | **Active** | KiCad 10.0.6 ERC: **0 violations** |
| **PCB Layout** | [`SHM_Node_R2.kicad_pcb`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Node_R2.kicad_pcb) | **Active** | KiCad 10.0.6 DRC: **0 violations, 0 unconnected, 0 parity issues** |
| **Circuit Spec** | [`circuit_spec.json`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/circuit_spec.json) | **Active** | Canonical JSON netlist/component specification |
| **Netlist** | [`SHM_Node_R2.net`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Node_R2.net) | **Active** | Exported XML netlist matching firmware pinouts |
| **Local Footprints** | [`SHM_Local.pretty/`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Local.pretty/) | **Active** | Contains `ESP32-S3-WROOM-1_Overhang.kicad_mod` |

---

## 2. Geometric & Reference Details

* **Authoritative Reference Board:** [`PCB Files/Reference PCB (OLD Version)/Thesis/SHM_PCB_New/SHM_PCB_New.kicad_pcb`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/Reference%20PCB%20(OLD%20Version)/Thesis/SHM_PCB_New/SHM_PCB_New.kicad_pcb)
* **Outline Geometry:** Exact 12-edge primitive profile with **79.50 mm × 50.45 mm** centerline bounds.
* **Layer Stack:** 4-layer board (F.Cu signal, In1.Cu GND plane, In2.Cu GND plane, B.Cu signal/power).
* **Components:** 38 assembled schematic components + 11 test pad features (U1: ESP32-S3-WROOM-1-N16R8, U2/U3/U4: triaxial MPU-6050 ICs, U5: AP7361C 3.3V LDO, U6: USBLC6-2SC6 ESD protection, J1: USB-C 16P, J2: 3-pin UART debug header).

---

## 3. Subdirectories

1. [`superseded_wrong_83mm_outline/`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/superseded_wrong_83mm_outline/)
   * **DO NOT USE.** Holds the superseded 83.6 mm board that accidentally used the wrong outline from `Thesis.kicad_pcb`.
2. [`reference_corrected/`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/reference_corrected/)
   * The intermediate staging sandbox used during routing/finishing before the finalized board was promoted to this directory.

---

## 4. Verification Commands (Reproduce with KiCad 10.0.6)

```powershell
# 1. Run Electrical Rules Check (ERC) on Schematic
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' sch erc --format json -o 'PCB Files/GPT Build - PCB/reports/erc_active_promoted.json' 'PCB Files/GPT Build - PCB/design/SHM_Node_R2.kicad_sch'

# 2. Run Design Rules Check (DRC) on PCB Layout
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' pcb drc --format json --refill-zones --schematic-parity -o 'PCB Files/GPT Build - PCB/reports/drc_active_promoted.json' 'PCB Files/GPT Build - PCB/design/SHM_Node_R2.kicad_pcb'

# 3. Run Independent Geometry and Net Verification
& 'C:/Program Files/KiCad/10.0/bin/python.exe' 'PCB Files/GPT Build - PCB/tools/verify_corrected_board.py' --board 'PCB Files/GPT Build - PCB/design/SHM_Node_R2.kicad_pcb' --output 'PCB Files/GPT Build - PCB/reports/geometric_net_audit_active.json'
```
