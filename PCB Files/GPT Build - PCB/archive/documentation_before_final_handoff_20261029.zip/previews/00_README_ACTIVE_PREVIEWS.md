# ACTIVE VISUAL PREVIEWS — SOURCE OF TRUTH

> **FOR ALL USERS AND AI ASSISTANTS:**
> This directory (`PCB Files/GPT Build - PCB/previews/`) contains **ONLY the current, verified visual exports** of the active `SHM_Node_R2` schematic and corrected 79.50 × 50.45 mm PCB layout.

---

## Active Visual Previews

| File Name | Format | Content Description |
| :--- | :---: | :--- |
| [`active_schematic.png`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_schematic.png) | PNG (200 DPI) | Full high-resolution render of the active schematic ([`SHM_Node_R2.kicad_sch`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/SHM_Node_R2.kicad_sch)) |
| [`active_schematic.svg`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_schematic.svg) | Scalable Vector | Vector export of the active schematic |
| [`SHM_Node_R2_schematic.pdf`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/SHM_Node_R2_schematic.pdf) | Vector PDF | Printable vector PDF of the active schematic |
| [`active_pcb_3d_top.png`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_pcb_3d_top.png) | PNG (1080p) | Photorealistic raytraced 3D render of the top side of the active 79.50 × 50.45 mm PCB |
| [`active_pcb_3d_bottom.png`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_pcb_3d_bottom.png) | PNG (1080p) | Photorealistic raytraced 3D render of the bottom side of the active 79.50 × 50.45 mm PCB |
| [`active_pcb_top.svg`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_pcb_top.svg) | Scalable Vector | 2D vector plot of the top copper (`F.Cu`), silkscreen (`F.SilkS`), and edge cuts (`Edge.Cuts`) |
| [`active_pcb_bottom.svg`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/previews/active_pcb_bottom.svg) | Scalable Vector | 2D vector plot of the bottom copper (`B.Cu`), silkscreen (`B.SilkS`), and edge cuts (`Edge.Cuts`) |

---

## Where Are the Old/Superseded Previews?
All superseded previews of the old 83.6 mm board (e.g., `routed_board_top.png`, `routed_board_top.svg`, `routed_top.svg`, `placement.png`, etc.) have been moved to:
📁 [`PCB Files/GPT Build - PCB/design/superseded_wrong_83mm_outline/previews/`](file:///d:/Antigravity/Projects/SHM-Capstone/PCB%20Files/GPT%20Build%20-%20PCB/design/superseded_wrong_83mm_outline/previews/)
