# SHM frequency acquisition hardware

Working KiCad design for **ESP32-S3-WROOM-1-N16R8**, **three bare MPU-6050 ICs**, external USB-C power and native USB programming. The user authorized this hardware phase on 2026-10-25. The research deliverable is independent X/Y/Z frequency acquisition from each device on one rigid roadway-deck monitoring node.

**Status, 2026-10-28: correcting the board to the user-specified old reference; not released for fabrication.** The only intended reference is `../Reference PCB (OLD Version)/Thesis/SHM_PCB_New/`, specifically its root `SHM_PCB_New.kicad_sch` and `.kicad_pcb`. The parent `Thesis.kicad_pcb` and nested `SHM_Proto_PCB` are historical alternatives, not the selected reference. Read [HANDOFF](docs/HANDOFF.md) before using the native `design/SHM_Node_R2.kicad_pro`, `.kicad_sch` and `.kicad_pcb` files.

Start with [PROJECT_MAP](docs/PROJECT_MAP.md), [DECISION_MAP](docs/DECISION_MAP.md), and [REFERENCE_REVIEW](docs/REFERENCE_REVIEW.md). The intended compact three-lobe outline measures **79.50 x 50.45 mm at the edge centerline**, or79.60 x50.55mm including its0.10mm stroke. The saved R2 inspected at the correction checkpoint instead used the larger83.61 x83.12mm outline; that prior selection is superseded. Placement, mounting, antenna clearance, routing and CAD checks must be reviewed for the corrected geometry. Four copper layers remain an engineering choice subject to stackup review, not a property inherited from the two-layer reference.

The2026-10-26 CAD snapshot in `../../MD Files/14_CAD_VALIDATION_SNAPSHOT.md` records zero active ERC/DRC violations for the old R2 hashes under configured checks. It remains historical evidence of those checks, but does not validate conformity to the corrected reference or any modified board. Current correction evidence is in `reports/reference/reference_correction_20261028.json`.

The electrical interface follows `../../Code Files/GPT Build/firmware/SHM_Capstone/hardware_profile.h`: bus0 GPIO8/9, bus1 GPIO10/11, separate data-ready GPIO4/5/6, native USB GPIO19/20. Historic single-bus address switching and GPIO35/36 routes must not be copied.

Source `.kicad_*` files, build scripts, measured validation reports and review images are separate artifacts. Passing ERC/DRC alone cannot establish power stability, USB signal integrity, mechanical coupling or measurement accuracy. A fabrication release additionally requires resolved footprints/part numbers, selected manufacturer stackup, manual USB/thermal review and documented remaining prototype measurements. No order or fabrication submission is authorized by the existence of this project folder.

Original reference projects and the approved research-paper DOCX are preserved. Future changes should update this map and [AGENTS.md](AGENTS.md) so another account or agent can continue from saved evidence.
